﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyBasedTesting.CSharp
{
    public static class ArrayUtils
    {
        public static T[] BubbleSort<T>(T[] input) where T : IComparable
        {
            if (input.Length == 0)
            {
                return input;
            }

            var result = new T[input.Length];
            input.CopyTo(result, 0);

            T temp = result[0];

            for (int i = 0; i < result.Length; i++)
            {
                for (int j = i + 1; j < result.Length; j++)
                {
                    if (result[i].CompareTo(result[j]) > 0)
                    {
                        temp = result[i];
                        result[i] = result[j];
                        result[j] = temp;
                    }
                }
            }

            return result;
        }


    }
}
