﻿module RatingProperties

open FsCheck
open FsCheck.Xunit
open PropertyBasedTesting.CSharp

// Arb.registerByType (typeof<RatingProperties>)
type RatingProperties =
    // generate list with values 1-5
    static member ratingValues = 
        let range = Arb.generate<int> |> Gen.suchThat ((>) 6) |> Gen.suchThat ((<) 0)
        Gen.listOf<int> range |> Arb.fromGen

    // Check.VerboseAll (typeof<RatingProperties>)
    static member ``Number of stars should be closest proximity discrete star to the average value`` (input : int list) =
        // create sut
        let rating = Rating()
        // send in ratings
        List.iter (fun v -> rating.Rate(v)) input
        // assert
        match rating.Stars with
        | 0.0 -> rating.Average = 0.0
        | 1.0 -> rating.Average < 1.25
        | 1.5 -> 1.25 <= rating.Average && rating.Average < 1.75
        | 2.0 -> 1.75 <= rating.Average && rating.Average < 2.25
        | 2.5 -> 2.25 <= rating.Average && rating.Average < 2.75
        | 3.0 -> 2.75 <= rating.Average && rating.Average < 3.25
        | 3.5 -> 3.25 <= rating.Average && rating.Average < 3.75
        | 4.0 -> 3.75 <= rating.Average && rating.Average < 4.25
        | 4.5 -> 4.25 <= rating.Average && rating.Average < 4.75
        | 5.0 -> 4.75 <= rating.Average
        | x -> false