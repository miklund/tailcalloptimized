﻿module ``ArrayUtils properties``

open FsCheck
open FsCheck.Xunit
open PropertyBasedTesting.CSharp

// Check.Verbose ``Sorting the list once = sorting the list twice``
[<Property>]
let ``Sorting the list once = sorting the list twice`` (input : int array) =
    ArrayUtils.BubbleSort input = ArrayUtils.BubbleSort(ArrayUtils.BubbleSort input)

// Check.Verbose ``First item is smallest``
[<Property>]
let ``First item is smallest`` (input : int array) =
    (input.Length) > 0 ==>
        lazy((ArrayUtils.BubbleSort input).[0] = Seq.min input)

// Check.Quick ``Last item is largest``
[<Property>]
let ``Last item is largest`` (input : int array) =
    (input.Length) > 0 ==>
        lazy((ArrayUtils.BubbleSort input).[input.Length - 1] = Seq.max input)

// Check.Quick ``Has same numbers as input list``
[<Property>]
let ``Has same numbers as input list`` (input : int array) =
    let sorted = ArrayUtils.BubbleSort input
    
    (sorted.Length = input.Length)
        |@ "same length" .&.
    (sorted |> Seq.forall (fun x -> Seq.exists ((=) x) input))
        |@ "all elements exists"

// Check.Quick ``Is ordered``
[<Property>]
let ``Is ordered`` (input : int array) =
    ArrayUtils.BubbleSort input
        |> Seq.pairwise |> Seq.forall (fun (a, b) -> a <= b)