﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertyBasedTesting.CSharp
{
    public class Rating
    {
        private List<double> ratings = new List<double>();

        /// <summary>
        /// Send in the user rating
        /// </summary>
        /// <param name="value">A number 1 - 5</param>
        public void Rate(int value)
        {
            if (value < 1 || value > 5)
            {
                throw new ArgumentOutOfRangeException("value", "Please supply a rating valuein the range 1-5");
            }

            ratings.Add(value);
        }

        /// <summary>
        /// Returns the average rating value
        /// </summary>
        public double Average
        {
            get
            {
                if (ratings.Count > 0)
                {
                    return ratings.Average();
                }

                return .0;
            }
        }

        /// <summary>
        /// The number of stars to display, 1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5
        /// </summary>
        public double Stars
        {
            get
            {
                return Math.Round(2 * Average, MidpointRounding.AwayFromZero) / 2;
            }
        }

        public override string ToString()
        {
            return string.Format("{{Quantity: {0}; Average: {1:0.00}; Stars: {2:0.0}}}", ratings.Count, Average, Stars);
        }
    }
}
